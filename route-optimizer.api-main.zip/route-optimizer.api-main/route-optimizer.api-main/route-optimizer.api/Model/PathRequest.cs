﻿namespace route_optimizer.api.Model
{
    public class PathRequest
    {
        public string From { get; set; }
        public string To { get; set; }
        public List<Node> Graph { get; set; } = new List<Node>();
    }
}
