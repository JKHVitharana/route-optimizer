﻿namespace route_optimizer.api.Model
{
    public class Edge
    {
        public Node ToNode { get; set; }
        public int Weight { get; set; }
    }
}
