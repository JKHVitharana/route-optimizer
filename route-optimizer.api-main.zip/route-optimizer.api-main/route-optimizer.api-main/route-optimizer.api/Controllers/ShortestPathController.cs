﻿using Microsoft.AspNetCore.Mvc;
using route_optimizer.api.Model;
using route_optimizer.api.Service;

namespace route_optimizer.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ShortestPathController : ControllerBase
    {
        private readonly ShortestPathService _shortestPathService;

        public ShortestPathController()
        {
            _shortestPathService = new ShortestPathService();
        }

        [HttpPost("calculate")]
        public IActionResult CalculateShortestPath([FromBody] PathRequest request)
        {
            if (string.IsNullOrEmpty(request.From) || string.IsNullOrEmpty(request.To))
            {
                return BadRequest("Both From and To nodes are required.");
            }

            var result = _shortestPathService.CalculateShortestPath(request.From, request.To);
            return Ok(result);
        }
    }
}


